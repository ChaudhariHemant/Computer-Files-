Q) Diff in overloading and overriding

Method overloading is when multiple methods in the same class have the same name but different parameters, and it is resolved at compile time, whereas method overriding is when a subclass provides a specific implementation of a method that is already defined in its parent class, and it is resolved at runtime. Overloading does not require inheritance  while overriding strictly requires inheritance and is used to achieve runtime polymorphism. In overloading, the return type can be different but must follow method signature rules, whereas in overriding the return type must be the same or covariant with the parent method. Overloading happens within a single class, while overriding happens between parent and child classes.



@)How does JVM memory structure work? (Heap, Stack, Metaspace)

JVM Memory Structure (Heap, Stack, Metaspace):

The JVM memory is divided into different areas to manage data efficiently during program execution.

Heap: Stores all objects and their instance variables. It is shared among all threads and managed by Garbage Collector.

Stack: Each thread has its own stack. It stores method calls, local variables, and references to objects. Memory is automatically cleared after method execution.

Metaspace: Stores class metadata like class definitions, methods, and static variables. It replaced PermGen in Java 8 and grows dynamically.

Together, these memory areas help JVM manage execution, objects, and class information efficiently.



Q)4. What causes OutOfMemoryError in production? How would you debug it?

OutOfMemoryError happens when JVM runs out of heap memory to create new objects.

It is mainly caused by memory leaks, large data loading, or too many objects in memory.

In production, it can also happen due to improper caching or unclosed resources.

To debug, we analyze heap dumps and GC logs using tools like VisualVM or Eclipse MAT.

Then we find heavy objects and optimize or fix memory usage in the code.



Q)5. How do you make a class thread-safe? Give a real time scenario.

To make a class thread-safe, we ensure that only one thread can access critical code at a time to avoid data inconsistency.

We can achieve this using synchronization (synchronized keyword), locks, atomic classes, or making the class immutable.

A real-time example is a bank account withdrawal system, where multiple users try to withdraw money at the same time, so we synchronize the balance update method.

This prevents race conditions and ensures correct balance updates.

Thread-safe design is important in multi-user systems like banking or booking applications.



@)what is immutable class and how it make

An immutable class is a class whose state (data) cannot be changed after it is created. Once an object is created, its values remain constant throughout its lifetime.

To make a class immutable in Java:

Declare the class as final so it cannot be extended.

Make all fields private and final.

Do not provide setter methods.

Initialize all fields using a constructor only.

If it contains mutable objects, return deep copies instead of direct references.

Example: String class in Java is immutable.

Benefit: It is automatically thread-safe because no thread can modify its state after creation, making it safe in multi-threaded environments.



&#x20;





@) Diff in arrayList and Linkdea list

ArrayList is based on a dynamic array, so it provides fast random access but slow insertion and deletion due to shifting of elements. LinkedList is based on a doubly linked list, so it provides fast insertion and deletion but slower access since traversal is required. ArrayList uses less memory, while LinkedList uses more due to pointer storage. So we use ArrayList when read operations are more and LinkedList when modification operations are more.”



Q)Static keyword

Static is a keyword in Java used for memory management purposes. If a variable is declared as static, it is shared among all objects of the class and can be accessed using the class name. If a method is static, we can call it directly without creating an object of the class. Static members belong to the class, not to individual objects. This helps in saving memory and is used for common data or utility methods.



Q)The Collection Framework

The Collection Framework in Java is a set of classes and interfaces used to store and manage groups of objects efficiently. It provides ready-made data structures like List, Set, Queue, and Map to perform operations such as adding, removing, searching, and sorting data. List allows duplicate elements and maintains order, Set does not allow duplicates, Queue follows FIFO order, and Map stores data in key-value pairs. It reduces coding effort by providing built-in methods and improves performance and reusability. Common classes include ArrayList, LinkedList, HashSet, TreeSet, HashMap, and others





Q) HashMap

HashMap is a class in Java that implements the Map interface and stores data in key-value pairs using hashing.HashMap is not thread-safe. Keys must be unique, while values can be duplicated. It allows one null key and multiple null values. HashMap is not synchronized and does not maintain any order. By default, it has an initial capacity of 16 and a load factor of 0.75. When the number of entries exceeds 12, it resizes to 32 and rehashes the existing entries.



Q)1. What is Hashing?

Hashing is a technique used to convert a key into a unique hash code using a hash function, which determines where the value will be stored in HashMap.



Q)HashMap and ConcurrentHashMap diff ?

HashMap and ConcurrentHashMap both store data in key-value pairs, but the main difference is thread safety. HashMap is not thread-safe, so it is used in single-threaded environments, while ConcurrentHashMap is thread-safe and designed for multi-threaded environments. HashMap allows one null key and multiple null values, whereas ConcurrentHashMap does not allow any null keys or values. In terms of performance, HashMap is faster in a single-threaded scenario, while ConcurrentHashMap provides better performance in multi-threaded scenarios using internal locking mechanisms.





Q)Diff in Closeable and autoCloseable

Closeable is an interface in Java used for releasing resources mainly in input/output operations like files and streams, while AutoCloseable is a more general interface used for automatic resource management with try-with-resources. Closeable is present in the java.io package and its close() method throws only IOException, while AutoCloseable is present in the java.lang package and its close() method can throw any type of exception, making it more flexible. Closeable is less flexible and was introduced in Java 5. AutoCloseable was introduced in Java 7, is more flexible, and Closeable is actually a sub-interface of AutoCloseable.



Q) HashMap Internally work?

HashMap internally uses an array of buckets to store key-value pairs. When a key-value pair is inserted, the key’s hashCode() is calculated and converted into an index using a hashing function. It uses both hashCode() and equals() methods to store and retrieve data correctly. The data is stored in buckets, and if multiple keys map to the same hashcode a collision occurs, which is handled using a LinkedList or a Tree (after Java 8). When the number of entries exceeds the load factor threshold (0.75), HashMap performs rehashing by resizing and redistributing the entries.



Q)List vs Set vs Map

List allows duplicate elements and maintains insertion order, Set does not allow duplicates and may or may not maintain order depending on implementation, while Map stores data in key-value pairs where keys are unique. List stores single values, Set also stores single values but unique ones, and Map stores key and value together. List and Set are part of Collection interface, but Map is separate. I use List for ordered data, Set for unique data, and Map for key-based lookup.



Q)HashMap vs HashSet

HashMap stores data in key-value pairs where keys must be unique and values can be duplicate, whereas HashSet stores only unique elements without key-value pairs. HashMap allows one null key and multiple null values, while HashSet allows only one null element. Internally, HashSet uses HashMap to store values. I use HashMap for mapping data and HashSet for storing unique items.



Q)TreeSet vs TreeMap

TreeSet stores only unique elements in sorted order, while TreeMap stores key-value pairs in sorted order based on keys. TreeSet is implemented using TreeMap internally, and TreeMap is implemented using Red-Black Tree. TreeSet does not allow duplicates, whereas TreeMap allows duplicate values but not duplicate keys. I use TreeSet when I need sorted unique values and TreeMap when I need sorted key-value data.



Q)Why Java is WORA? Write Once, Run Anywhere

Java is called WORA because once we write and compile Java code, it gets converted into bytecode, which is platform-independent. This bytecode can run on any system that has a Java Virtual Machine (JVM), regardless of the operating system. The JVM converts the same bytecode into machine code specific to that system. So, we don’t need to rewrite or recompile the program for different platforms. That is why Java is known as “Write Once, Run Anywhere.”



Q)Instance Methoda and Static Methoda

An instance method belongs to an object of a class and works on instance variables. It must be called using an object of the class. It is created when an object is created. A static method belongs to the class itself and does not require an object, so it can be called using the class name without creating an object. It is created once when the class is loaded. An instance method can access both instance variables and static variables directly, whereas a static method can access only static variables directly and cannot access instance variables without an object.



Q)Multithreading in Java

Multithreading in Java is a feature that allows multiple threads to run simultaneously within a single program, helping in better CPU utilization and faster execution. A thread is a lightweight sub-process, and multiple threads can perform different tasks at the same time, such as one thread handling user input while another performs calculations. Java supports multithreading using the Thread class and Runnable interface. Each thread runs independently but shares the same memory space, which makes communication between threads easy but also requires synchronization to avoid data inconsistency. Multithreading is commonly used in applications like games, web servers, and real-time systems to improve performance and responsiveness.



Q)Thread Life Cycle in Java

State	                         Description

New	                   Thread object is created but not started

Runnable	           Thread is ready to run and waiting for CPU

Running	                   Thread is executing the task

Waiting / Blocked	   Thread waits for another thread or resource

Terminated	           Thread execution is completed



Q)What is wait() and notify() in Java?

wait() is used to pause a thread until another thread sends a notification.

notify() wakes up one waiting thread, while notifyAll() wakes all waiting threads.

These methods are used for inter-thread communication.

They must be called inside a synchronized block or method.



Q)Diff in wait and sleep

wait Belongs to Object class and sleep Belongs to Thread class. wait() is used for inter-thread communication, where one thread waits until another thread sends a notification. sleep() is used to pause execution of a thread for a specific time. wait() releases the lock on the object while waiting, so other threads can access it. sleep() does not release the lock, so other threads cannot access the locked resource. wait() must be called inside a synchronized block or method, whereas sleep() does not require synchronization and can be called anywhere in the code.



Q)5. What is Executor Framework in Java?

The Executor Framework is used to manage and control thread execution.

It provides a pool of threads to execute tasks efficiently.

It reduces the overhead of creating and managing threads manually.

It is part of java.util.concurrent package.



Q)User Thread vs Daemon Thread

In Java, a User Thread is used to perform the main tasks of the application, such as executing business logic or handling user operations. The JVM waits until all user threads complete their execution before terminating the program.



A Daemon Thread is a background service thread that supports user threads by performing tasks like garbage collection or monitoring. The JVM does not wait for daemon threads to finish, and they automatically stop when all user threads are completed.



Q)Why do we use Executor Framework instead of Threads?

Executor Framework improves performance by reusing existing threads.

It avoids the cost of creating new threads every time.

It provides better control over thread lifecycle and execution.

It is more scalable for large applications.



Q)7. What is Thread Pool in Executor Framework?

A thread pool is a group of pre-created threads ready to execute tasks.

Tasks are assigned to available threads instead of creating new ones.

It improves performance and resource management.

It is created using Executors like newFixedThreadPool().



Q)What are the types of Executor Services?

Common types are SingleThreadExecutor, FixedThreadPool, and CachedThreadPool.

SingleThreadExecutor uses only one thread for all tasks.

FixedThreadPool uses a fixed number of threads.

CachedThreadPool creates new threads as needed.



Q)difference between synchronized and non-synchronized in Java

Synchronized means only one thread can access a method or block at a time, so it is used to avoid data inconsistency in a multi-threaded environment, but it makes the program slower because threads have to wait for each other. Non-synchronized means multiple threads can access a method at the same time, which makes it faster, but it is not safe in a multi-threaded environment because it can lead to data inconsistency. So, synchronized is used when thread safety is important, while non-synchronized is used when performance is more important and there is no risk of shared data issues.



Q)Garbage Collection in Java

Garbage Collection in Java is an automatic memory management process used by the JVM to remove unused or unreachable objects from memory. When an object has no references, it becomes eligible for garbage collection, and the Garbage Collector frees heap memory to improve performance. Before destroying an object, the JVM calls the finalize() method (finalizer method), which is used for cleanup activities, but its execution is not guaranteed. After garbage collection, the memory is released automatically, so we do not need to delete objects manually.





Q)What is Exception Handling in Java?

Exception handling is a way to handle runtime errors so that the program does not terminate abnormally.

It uses try-catch blocks to handle exceptions.

It helps maintain normal program flow.

It improves program reliability.



Q)What is an Exception?

An exception is an event that disrupts normal program flow during execution.

It occurs due to runtime errors like divide by zero or null pointer.

Java provides exception classes to handle such errors.

It can be handled using try-catch blocks.



Q)Difference between throw and throws and throwble

**throw** is used to explicitly throw an exception in the code. **throws** is used to declare exceptions. **Throwable** is the parent class of all exceptions and errors in Java. **throw** is used inside a method or block. **throws** is used in a method signature. **Throwable** It has two main subclasses: Exception and Error. **throw** is used to throw only a single exception object at a time. **throws** can declare multiple exceptions at once. **Throwable** is used as a base class for all throwable objects in Java.



Q)Checked exceptions and Unchecked exceptions

Checked exceptions are those exceptions which are checked at compile time, for example IOException. Unchecked exceptions are those exceptions which occur at runtime, for example NullPointerException. Checked exceptions are handled using try-catch block. Unchecked exceptions are not mandatory to handle using try-catch. Checked exceptions, if not handled, will give a compilation error, so handling is mandatory. Unchecked exceptions occur due to programming mistakes like invalid input or null references.



1\. IOException

Cause: It occurs when there is a problem in input/output operations like file not found or reading a file that does not exist.

Example: Trying to read a file that is missing in the system.

2\. SQLException

Cause: It occurs when there is an error while interacting with a database like wrong query or connection failure.

Example: Executing an invalid SQL query or database not connected.



Unchecked Exceptions (Runtime exceptions)

1\. NullPointerException

Cause: It occurs when we try to access or use an object that is null (not initialized).

Example: Calling a method on a null object reference.



ArithmeticException

Cause: It occurs when invalid arithmetic operations happen like division by zero.

Example: 10 / 0 in Java code.



Q)why private methoda , static methoda ,final methoda ,constructor canoot be override

Private methods cannot be overridden because they are only accessible within the same class, so they are not visible to the subclass. Since overriding requires method visibility in the child class, private methods are not inherited and therefore cannot be overridden. Static methods cannot be overridden because they belong to the class, not the object, and method binding for static methods happens at compile time (this is called method hiding, not overriding). Final methods cannot be overridden because they are declared as final to prevent modification, meaning their implementation is fixed and cannot be changed in any subclass.A constructor cannot be overridden because it is not inherited by subclasses. Overriding works only for inherited methods, but constructors are used only for object initialization of their own class. However, constructors can be overloaded within the same class.



@)difference between Stack and Queue

A Stack is a linear data structure that follows the LIFO (Last In First Out) principle, meaning the last element inserted is the first one to be removed, and operations like insertion and deletion happen from the same end called the top. In contrast, a Queue is a linear data structure that follows the FIFO (First In First Out) principle, meaning the first element inserted is the first one to be removed, and insertion happens at the rear while deletion happens from the front. Stack is used in scenarios like function calls, undo operations, and expression evaluation, whereas Queue is used in scheduling, printer tasks, and handling requests in order. Both are part of the Java Collection Framework and help in managing data in different ordered ways.



@)instance variable and static variable

An instance variable in Java belongs to an object of a class, and each object has its own separate copy of that variable .static variable belongs to the class itself and is shared among all objects, so any change made to it is reflected across all objects.instance variable is created when an object is created and is accessed using the object reference. A static variable is created only once when the class is loaded and is usually accessed using the class name.Instance variables are used for object-specific data, whereas static variables are used for common data shared by all objects.





Q) Abstract class and interface

&#x20;Abstract class can have both abstract and concrete methods, whereas an interface mainly contains abstract methods, but from Java 8 onward, it can also have default and static methods. An abstract class supports single inheritance, while an interface supports multiple inheritance. Variables in an abstract class can have any access modifier, whereas in an interface, variables are always public, static, and final by default, so they act as constants and cannot be modified. An abstract class can have instance variables and constructors, but an interface cannot have constructors and only contains constants as variables. We use an abstract class when classes are closely related and share common behavior, while an interface is used when unrelated classes need to follow the same contract or behavior.



Q)HashMap and HashSet

HashMap and HashSet are both part of the Java Collection Framework, but they are used for different purposes. HashMap stores data in key-value pairs, where each key is unique and maps to a value, whereas HashSet stores only unique elements and does not use key-value pairs. In HashMap, duplicate keys are not allowed but values can be duplicated, while in HashSet, duplicate elements are completely not allowed. HashMap is mainly used when we need to store and retrieve data using a key, whereas HashSet is used when we only need to store unique elements. Internally, HashSet uses a HashMap for storing data, where elements act as keys. Overall, HashMap is for key-value mapping, while HashSet is for storing unique values only.





Q)Lazy Loading vs Eager Loading

In lazy loading, data is not loaded immediately when the object is created; in eager loading, all related data is loaded immediately at the time of object creation. Using lazy loading improves startup performance and saves memory, whereas eager loading increases memory usage and can reduce performance. Lazy loading can lead to issues like N+1 queries or LazyInitializationException, and eager loading can reduce performance if unnecessary data is loaded.



Q)N+1 problem

The N+1 problem is a common performance issue that occurs in ORM frameworks like Hibernate. N+1 problem occurs when one query fetches main data and N additional queries are executed for related data, causing performance issues due to excessive database calls. It can be solved by using JOIN FETCH, batch fetching, or appropriate use of eager loading to reduce the number of database queries.



EX)If you fetch a list of 10 users, and for each user you fetch their orders separately, the database runs:

1 query for users

10 queries for orders

&#x20;Total = 11 queries (1 + N)

This is called the N+1 problem.





Q)Fail-fast and fail-safe

Fail-fast and fail-safe are two types of iterators used in Java collections. A fail-fast iterator throws a ConcurrentModificationException if the collection is modified during iteration because it works on the original collection. In contrast, a fail-safe iterator does not throw an exception and allows modification during iteration because it works on a copy of the collection. Fail-fast is faster and memory efficient, while fail-safe is slower and uses extra memory.”



Q)HashMap and Hashtable

HashMap is not synchronized, which makes it faster and more suitable for non-threaded environments, whereas Hashtable is synchronized and thread-safe but slower due to overhead. HashMap allows one null key and multiple null values, while Hashtable does not allow any null key or value. Additionally, HashMap is part of the modern Java Collections Framework, whereas Hashtable is a legacy class.”



@) Comparable vs Comparator

Comparable is used to define the natural or default sorting of an object, whereas Comparator is used to define custom sorting logic. Comparable is present in the java.lang package, while Comparator is present in the java.util package. Comparable uses the compareTo() method, whereas Comparator uses the compare() method. In Comparable, the sorting logic is written inside the class, while in Comparator, the sorting logic is written outside the class. Additionally, Comparable allows only one type of sorting, whereas Comparator supports multiple sorting logics.





Q)string stringbuffer stringbuilder

The main feature of String in Java is that it is immutable, which means once a String object is created its value cannot be changed, and any modification like concatenation creates a new object in memory, which can increase memory usage if done frequently. The feature of StringBuilder is that it is mutable, so we can modify the same object without creating new ones, making it efficient for operations like appending or concatenation in a single-threaded environment. The feature of StringBuffer is that it is also mutable like StringBuilder but additionally it is thread-safe because its methods are synchronized, which makes it suitable for multi-threaded environments. In terms of performance, String is slower when frequently modified because it creates new objects every time, whereas StringBuilder gives better performance since it modifies the same object without synchronization overhead. StringBuffer is slightly slower than StringBuilder because of synchronization, but it provides safety in multi-threaded scenarios. Overall, String is best when data is constant, StringBuilder is best for fast operations in single-threaded programs, and StringBuffer is preferred when thread safety is required.





Q)What actually happens when you use @Transactional?

When you use @Transactional, Spring creates a proxy around your method or class.

Before the method starts, Spring opens a database transaction. If the method executes successfully, Spring commits the transaction.

If any runtime exception occurs, Spring automatically rolls back the transaction to maintain data consistency.

This is handled internally using AOP (Aspect-Oriented Programming), so you don’t need to write manual transaction code.







Q)How do you handle concurrent updates to the same database row

We handle concurrent updates using locking mechanisms to avoid data inconsistency.

Optimistic Locking: Uses a @Version field. If two users update the same row, the second update fails if version mismatches, preventing overwriting.

Pessimistic Locking: Locks the row when one transaction is updating it, so other transactions must wait until it is released.

Transaction Management: We use @Transactional to ensure atomic updates.

In real projects, optimistic locking is commonly used for better performance, and pessimistic locking is used for high-conflict scenarios like banking systems.



Q)Explain ACID properties with a banking transaction example.

ACID properties in banking system:

Atomicity: Transaction is all or nothing. If money is debited, it must also be credited; otherwise rollback happens.

Consistency: Total balance remains correct before and after the transaction.

Isolation: Multiple users can do transactions at the same time without affecting each other.

Durability: Once transaction is successful, data is permanently saved even if system crashes.



















=================================================== SPRING BOOT ==================================================================



Q)IOC and Di

IoC (Inversion of Control) is a concept where the control of object creation and management is given to the Spring container, whereas DI (Dependency Injection) is the technique used to achieve IoC. IoC means the framework controls the flow of the program, while DI means injecting required dependencies into a class instead of creating them manually. IoC is a broader principle, while DI is a specific implementation of that principle. In simple terms, IoC is the idea, and DI is the way to implement it.



@)Spring Boot Actuator

Spring Boot Actuator is used to monitor and manage a running application. It provides ready-made endpoints like health and metrics, which help check if the application is working properly. For example, we can use the health endpoint to see if the app is up or down. It is very useful for debugging, tracking performance, and managing the application in production.”



Q)The difference between Controller and RestController

A Controller (@Controller) is used to return views like JSP or HTML pages, while a RestController (@RestController) is used to return JSON or data. In a Controller, it requires @ResponseBody to return data, whereas RestController does not require @ResponseBody. Controller is used for web applications, and RestController is used to build REST APIs.



Q)@GetMapping is used to retrieve data from the server and mainly for reading data from the database.

@PostMapping is used to send data to the server, usually to create a new record in the database, and every time it creates a new entry.

@PutMapping is used to update an existing resource, and if the resource does not exist, it can also create it depending on implementation.

@PatchMapping is used to partially update an existing resource, meaning it updates only specific fields instead of the whole object.



Q)1. What is the difference between @Component, @Service, and @Repository?

All are stereotype annotations in Spring.

@Component is a generic annotation for any bean.

@Service is used for business logic layer.

@Repository is used for DAO layer and handles database exceptions.



Q)What is @Bean annotation?

It is used to declare a bean manually.

Defined inside a @Configuration class.

Spring manages its lifecycle.

Used when we need custom configuration.



Q)What is Dependency Injection in Spring Boot?

Dependency Injection is a design pattern used to inject objects into a class.

Spring manages object creation and dependency handling.

It reduces tight coupling between components.

It is done using @Autowired or constructor injection,getter setter injection.



Q) What is @Configuration?

@Configuration is used to define configuration classes.

It contains methods annotated with @Bean.

It is used for manual bean creation.

Spring processes it during application startup.



@RequestBody → Converts incoming JSON request into a Java object

@ResponseBody → Converts Java object into JSON response to client

&#x20;Note: If you use @RestController, @ResponseBody is applied automatically.





Q)6. Explain the complete lifecycle of a Spring Bean.

A Spring Bean goes through several phases managed by the Spring container. First, the bean is instantiated using its constructor. Then dependencies are injected using Dependency Injection. After that, Spring calls Aware interfaces and BeanPostProcessor (before initialization) methods.

Next, the bean enters the initialization phase, where methods like @PostConstruct or afterPropertiesSet() are executed. Once initialized, the bean is ready to use in the application. Finally, when the container is shut down, Spring calls destroy methods like @PreDestroy to clean up resources.



Q)How does Dependency Injection work internally in Spring?

Spring uses an IoC (Inversion of Control) container to manage objects. Instead of creating objects using new, Spring creates and manages them automatically.

When the application starts, Spring scans configuration (annotations like @Component, @Service, @Bean) and registers all classes as beans in the container. Then it creates objects using reflection and stores them in the ApplicationContext.

When a class needs a dependency, Spring injects the required bean automatically using constructor, setter, or field injection. It resolves dependencies and wires objects together internally.

This process is handled using reflection + BeanFactory + ApplicationContext, making object creation and management automatic and loosely coupled.







Q)How would you handle global exception handling in Spring Boot?

In Spring Boot, global exception handling is done using @ControllerAdvice.

We create a separate class annotated with @ControllerAdvice, which acts as a centralized exception handler for all controllers. Inside it, we define methods using @ExceptionHandler to handle specific exceptions like NullPointerException or custom exceptions.

When an exception occurs anywhere in the application, Spring automatically routes it to this global handler instead of showing a raw error.

We can also return proper HTTP status codes and custom error messages to the client for better API response handling.





Q)How would you design pagination \& sorting in a REST API?

Designing Pagination \& Sorting in REST API:

We design pagination using query parameters like page and size to control how much data is returned in one response. For example: GET /users?page=0\&size=10.

For sorting, we use a sort parameter, such as sort=name,asc or sort=id,desc.

In Spring Boot, we use Pageable interface, which automatically handles pagination and sorting at the database level.

This approach improves performance by loading only required data instead of fetching the full dataset.



Q)JWT Authentication (step-by-step):

First, the user sends login credentials (username/password) to the server. The server verifies the credentials and, if valid, generates a JWT token containing user info and a secret signature. This token is sent back to the client.

Next, the client stores the token (usually in local storage or cookies) and sends it in the Authorization header (Bearer token) with every request.

The server then validates the token signature and expiry time on each request. If valid, the request is allowed; otherwise, it is rejected.

👉 In short: Login → Token generated → Token sent → Token verified → Access granted.





Q)If your API is slow under load, how would you identify the bottleneck?

If an API is slow under load, I first identify where the delay is happening by checking each layer step by step.

I start with application logs and monitoring tools to see response time patterns. Then I check database performance using slow query logs and execution plans. If needed, I analyze CPU, memory, and thread usage of the application server.

I also use load testing tools like JMeter to reproduce the issue and find peak load behavior.

Finally, I isolate whether the bottleneck is in code, database, network, or external service, and then optimize that specific area.





Q)REST vs Messaging (Kafka), when would you choose which?

REST API:

Used for synchronous communication, where the client needs an immediate response. It is simple and commonly used for request-response operations like fetching user data or submitting forms.

&#x20;EX)



Kafka (Messaging):

Used for asynchronous communication, where systems don’t need an immediate response. It is best for event-driven systems like order processing, logging, or notification services.



👉 When to choose REST: real-time response needed (e.g., login, get user details).

👉 When to choose Kafka: high scalability, decoupling services, and background processing.



In short: REST = immediate response, Kafka = asynchronous and scalable processing



REST (Synchronous – Immediate response)

Used when user needs instant result:

Login / Authentication systems

Banking balance check

Fetch user profile (Amazon, Flipkart)

Search results (Google search API)

Payment status check



👉 Example: You click “Login” → server responds immediately.



Kafka (Asynchronous – Background processing)



Used when tasks can be processed later or in background:



Order processing (Amazon/Flipkart order placed → multiple services triggered)

Email/SMS notifications

Payment event tracking

Logging and analytics systems

Real-time data streaming (Uber, Zomato tracking)



👉 Example: You place an order → Kafka sends events to inventory, payment, delivery services.



Q)If two microservices fail during communication, how do you handle fault tolerance?

“If two microservices fail, I handle it using fault tolerance patterns.”

First, I use Retry mechanism to handle temporary failures.

Then I apply Circuit Breaker (like Resilience4j) to stop continuous calls to a failing service.

I also use a Fallback method to return default response so system doesn’t break.

And I set timeouts to avoid waiting indefinitely for response.

So overall, I ensure system stability using Retry, Circuit Breaker, Fallback, and Timeout mechanisms.”







=============================================================Hibernate ========================================================================



Q)Hiberante

Hibernate is an ORM (Object Relational Mapping) framework in Java. It is used to map Java objects to database tables. It eliminates the need to write complex SQL queries manually. Hibernate provides features like automatic table creation, caching, and transaction management, making database operations easier and faster.







Q)Hibernate caching

Hibernate caching helps make the application faster by reducing how many times it calls the database. It stores frequently used data in memory, so instead of going to the database again, it can reuse that data. The first-level cache is enabled by default and works within a single session, so repeated data is reused in the same request. The second-level cache is optional and works across multiple sessions using tools like Ehcache. Overall, caching improves performance and saves time.





Q) Diff in HQL and Sql

HQL works with Java objects, while SQL works with database tables. HQL is database-independent, meaning the same query works with different databases, whereas SQL can vary depending on the database. HQL is used in Hibernate, while SQL is used directly with the database. HQL uses entity class names and fields, while SQL uses table names and column names. HQL is not faster than SQL, while SQL is usually faster and more direct because it runs directly on the database.





Q)jpa

JPA (Java Persistence API) is a Java specification used to manage data between Java objects and databases. It provides a standard way to perform database operations like insert, update, delete, and fetch data. JPA works with ORM concepts and uses annotations like @Entity, @Table, and @Id. It does not have its own implementation, so it is commonly used with tools like Hibernate.



Q)What is lazy vs eager loading in JPA? When can it cause performance issues?

In JPA, lazy and eager loading define how related data is fetched from the database.

Lazy Loading: Data is loaded only when it is accessed. For example, if a user has orders, orders are fetched only when getOrders() is called. It improves performance by avoiding unnecessary data loading.

Eager Loading: Data is loaded immediately along with the main entity. So when you fetch a user, all related orders are also fetched at the same time, even if not needed.

&#x20;**Performance Issue :->**

Eager loading loads all related data even if not needed, which slows down queries and increases memory usage.

Lazy loading can cause the N+1 problem, where one main query triggers many small extra queries.

Improper mapping or configuration leads to high database load and poor performance.





Q)In Hibernate, there are mainly three types of queries:

1\. HQL (Hibernate Query Language)

It works with Java objects and entity classes.

It is database-independent.

Example: FROM Employee WHERE name='John'.

It supports joins and relationships between entities.

It is easy to read and similar to SQL syntax.



2\. SQL (Native Query)

It uses direct database SQL queries.

Works with tables and columns.

Used when we need full control over the database.

It is database-dependent.

It is useful for complex queries and stored procedures.



3\. Criteria Query (Criteria API)

It is used to create queries programmatically.

No need to write SQL or HQL manually.

Type-safe and dynamic query building.

It reduces syntax errors at compile time.

It is useful when conditions change at runtime.



4.Difference in SessionFactoy and Session

Final Answer:

A Session is a lightweight, short-lived object used to interact with the database for performing CRUD operations. In contrast, SessionFactory is a heavyweight, long-lived object responsible for creating Session instances. A Session is created and destroyed frequently for each database operation or request, whereas SessionFactory is created only once at application startup and lives throughout the application lifecycle. A Session is not thread-safe and should be used by only one thread at a time, whereas SessionFactory is thread-safe and can be shared across multiple threads safely. A Session is used to perform actual database operations like save, update, delete, and fetch data, whereas SessionFactory is used only to configure Hibernate and generate Session objects, not to directly interact with the database.



5.Difference between HQL, SQL, and Criteria Query

Answer:

HQL is object-oriented and works with entity classes, SQL is database-oriented and works with tables, whereas Criteria API is used to build queries programmatically without writing query strings. HQL is easy to read, SQL gives more control, and Criteria is best for dynamic queries.



6.Difference between get() and load() in Hibernate

Answer:

get() fetches data immediately from the database and returns null if the record is not found. In contrast, load() returns a proxy object and loads data only when needed, and it throws an exception if the data is not found.



7.Difference between save() and persist()

Answer:

save() returns the generated ID and immediately saves the object to the database, whereas persist() does not return anything and follows JPA standards. persist() may delay insertion until transaction commit, while save() ensures immediate insert.



8.Difference between update() and merge()

update() returns void and directly reattaches the given object to the session, whereas merge() returns a new persistent instance and keeps the original object detached, so you should use the returned object for further operations. Another difference is that update() throws an exception if an object with the same identifier is already present in the session, while merge() does not throw an error and instead merges the state of the given object into the existing persistent instance in the session.



9.Difference between transient, persistent, and detached states

A **transient** state object is newly created using new and is not associated with any session in frameworks like Hibernate ORM, whereas a **persistent** state object is associated with an active session and has a corresponding record in the database, and a **detached** state object was previously **persistent** but is no longer associated with any active session.

A **transient** state object does not have a database identity and no record exists in the database, whereas a **persistent** state object has a database identity (primary key) and is stored in the database, and a **detached state** object also has a database identity but is not currently managed by any session.

A **transient** state object is not tracked for changes and will not be saved automatically, whereas a **persistent** state object is automatically tracked and any changes are synchronized with the database, and a **detached** state object is not tracked for changes and must be reattached to a session to persist updates.



10.Difference between fetch() and load() (collection fetching concept)

Answer:

Fetch defines how related data is retrieved (lazy or eager), whereas load refers to retrieving a specific entity. Fetch strategy controls performance, while load is used for accessing data.



11.Difference between native SQL and HQL in performance

Answer:

Native SQL is generally faster because it directly interacts with the database, whereas HQL adds an abstraction layer and converts queries internally, which may add slight overhead but provides database independence.



12.Difference between openSession() and getCurrentSession()

Answer:

openSession() creates a new session every time and must be closed manually, whereas getCurrentSession() returns a session bound to the current context and is automatically managed by Hibernate. openSession() is not managed by the Hibernate context, while getCurrentSession() is managed by Hibernate using thread or context-based configuration. In terms of performance, openSession() can create multiple sessions leading to overhead, whereas getCurrentSession() reuses the session within the current context, making it more efficient.





13.Transaction vs Session

Answer:

Transaction is used to manage database operations (commit/rollback), whereas Session is used to interact with the database. Transaction ensures data consistency, while Session performs actual operations.



14.Interceptor vs EventListener

Answer:

Interceptor allows customization of Hibernate behavior globally or per session, whereas EventListener responds to specific events like save, update, or delete. Interceptor is more general, while EventListener is event-specific



15.StatelessSession vs Session

Answer:

Session supports caching and tracks object states, whereas StatelessSession does not support caching or tracking. StatelessSession is faster and used for bulk operations.



16.Query (HQL):

Query is used to execute HQL (Hibernate Query Language) queries, which work with Java objects and entity classes, not directly with database tables. It is database-independent, meaning the same query works for different databases. For example, instead of writing table names, we use class names like FROM Employee.



NativeQuery (SQLQuery):

NativeQuery is used to execute direct SQL queries on the database. It works with tables and columns, just like normal SQL. It is database-dependent and is mainly used when we need full control over the database, complex queries, or stored procedures.



import org.hibernate.Session;

import org.hibernate.SessionFactory;

import org.hibernate.Transaction;

import org.hibernate.cfg.Configuration;



* public class MainApp {



&#x20;   public static void main(String\[] args) {



&#x20;       // create SessionFactory

&#x20;       Configuration cfg = new Configuration();

&#x20;       cfg.configure("hibernate.cfg.xml");

&#x20;       cfg.addAnnotatedClass(Employee.class);



&#x20;       SessionFactory factory = cfg.buildSessionFactory();



&#x20;       // open session

&#x20;       Session session = factory.openSession();

&#x20;       Transaction tx = session.beginTransaction();



&#x20;       // ===== CREATE =====

&#x20;       Employee emp = new Employee();

&#x20;       emp.setName("Hemant");

&#x20;       emp.setSalary(50000);

&#x20;       session.save(emp);



&#x20;       // ===== READ =====

&#x20;       Employee e = session.get(Employee.class, 1);

&#x20;       if (e != null) {

&#x20;           System.out.println(e.getName());

&#x20;       }



&#x20;       // ===== UPDATE =====

&#x20;       if (e != null) {

&#x20;           e.setSalary(60000);

&#x20;           session.update(e);

&#x20;       }



&#x20;       // ===== DELETE =====

&#x20;       Employee del = session.get(Employee.class, 2);

&#x20;       if (del != null) {

&#x20;           session.delete(del);

&#x20;       }



&#x20;       // commit \& close

&#x20;       tx.commit();

&#x20;       session.close();

&#x20;       factory.close();

&#x20;   }





* }















===============================================JDBC=========================================================

q)What is JDBC?

JDBC (Java Database Connectivity) is an API used to connect Java applications with databases. It allows developers to execute SQL queries and retrieve results. JDBC provides classes and interfaces like Connection, Statement, and ResultSet. It supports different databases using drivers. It is used for performing database operations like insert, update, delete, and select.



Q)What are the main components of JDBC?

JDBC has components like DriverManager, Connection, Statement, and ResultSet. DriverManager is used to load database drivers. Connection is used to establish a connection with the database. Statement is used to execute SQL queries. ResultSet is used to store and process query results.



Q)Statement and PreparedStatement

Statement is used for simple SQL queries, while PreparedStatement is used for precompiled queries. Statement is less secure and slower, whereas PreparedStatement improves performance and security. Statement is vulnerable to SQL injection attacks, while PreparedStatement helps prevent SQL injection. Statement requires hardcoded values in the query, whereas PreparedStatement allows setting parameters dynamically. Statement executes queries directly each time, while PreparedStatement compiles the query once and can be reused multiple times.



Q)executeUpdate() is used for INSERT, UPDATE, and DELETE operations, and it returns the number of rows affected, whereas executeQuery() is used for SELECT (Read) operations and it returns a ResultSet containing the data retrieved from the database.



Q)What is ResultSet in JDBC?

ResultSet is an object that holds data returned from a query. It allows us to retrieve data row by row. It provides methods like next(), getString(), getInt(). It is used after executing SELECT queries. It helps in processing database results easily.



Q)Hibernate and jDBC

Hibernate is an ORM framework, while JDBC is an API used to connect Java with databases. Hibernate works with Java objects and automatically maps them to database tables, whereas JDBC works directly with SQL queries and tables. Hibernate reduces the need to write SQL queries, while in JDBC we have to write SQL manually. Hibernate provides features like caching and automatic table creation, while JDBC does not provide these features. Hibernate is easier to use but slightly slower, whereas JDBC gives better performance and more control over database operations. Hibernate is mainly used in large and complex applications for faster development, while JDBC is used in small applications or when we need direct control and high performance.





Using Statement

import java.sql.\*;



public class StatementCRUD {

&#x20;   public static void main(String\[] args) throws Exception {



&#x20;       Connection con = DriverManager.getConnection(

&#x20;               "jdbc:mysql://localhost:3306/testdb", "root", "password");



&#x20;       Statement stmt = con.createStatement();



&#x20;       // CREATE

&#x20;       stmt.executeUpdate("INSERT INTO employee VALUES(1, 'John', 50000)");



&#x20;       // READ

&#x20;       ResultSet rs = stmt.executeQuery("SELECT \* FROM employee");

&#x20;       while (rs.next()) {

&#x20;           System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getDouble(3));

&#x20;       }



&#x20;       // UPDATE

&#x20;       stmt.executeUpdate("UPDATE employee SET salary=60000 WHERE id=1");



&#x20;       // DELETE

&#x20;       stmt.executeUpdate("DELETE FROM employee WHERE id=1");



&#x20;       con.close();

&#x20;   }

}



**Using PreparedStatement.**

import java.sql.\*;

public class PreparedStatementCRUD {

&#x20;   public static void main(String\[] args) throws Exception {



&#x20;       Connection con = DriverManager.getConnection(

&#x20;               "jdbc:mysql://localhost:3306/testdb", "root", "password");



&#x20;       // CREATE

&#x20;       PreparedStatement psInsert = con.prepareStatement(

&#x20;               "INSERT INTO employee(id, name, salary) VALUES(?, ?, ?)");

&#x20;       psInsert.setInt(1, 1);

&#x20;       psInsert.setString(2, "John");

&#x20;       psInsert.setDouble(3, 50000);

&#x20;       psInsert.executeUpdate();



&#x20;       // READ

&#x20;       PreparedStatement psSelect = con.prepareStatement(

&#x20;               "SELECT \* FROM employee WHERE id=?");

&#x20;       psSelect.setInt(1, 1);

&#x20;       ResultSet rs = psSelect.executeQuery();

&#x20;       while (rs.next()) {

&#x20;           System.out.println(rs.getInt("id") + " " +

&#x20;                              rs.getString("name") + " " +

&#x20;                              rs.getDouble("salary"));

&#x20;       }



&#x20;       // UPDATE

&#x20;       PreparedStatement psUpdate = con.prepareStatement(

&#x20;               "UPDATE employee SET salary=? WHERE id=?");

&#x20;       psUpdate.setDouble(1, 60000);

&#x20;       psUpdate.setInt(2, 1);

&#x20;       psUpdate.executeUpdate();



&#x20;       // DELETE

&#x20;       PreparedStatement psDelete = con.prepareStatement(

&#x20;               "DELETE FROM employee WHERE id=?");

&#x20;       psDelete.setInt(1, 1);

&#x20;       psDelete.executeUpdate();



&#x20;       con.close();

&#x20;   }

}





================================================ SQl  ==============================================================================================================

SQL



Q) ACID properties in banking system:



Atomicity: Transaction is all or nothing. If money is debited, it must also be credited; otherwise rollback happens.



Consistency: Total balance remains correct before and after the transaction.



Isolation: Multiple users can do transactions at the same time without affecting each other.



Durability: Once transaction is successful, data is permanently saved even if system crashes.



Q) How to optimize a slow SQL query (simple answer):



To optimize a slow SQL query, first we check the execution plan to understand where time is being spent.

Then we add proper indexes on frequently used columns to speed up data retrieval.

We also avoid using SELECT \* and fetch only required columns.

Complex joins and subqueries are simplified wherever possible.

Finally, we reduce unnecessary data loading by filtering data properly using WHERE conditions.



What is MySQL?



MySQL is an open-source relational database management system.

It is used to store, manage, and retrieve data efficiently.

MySQL uses SQL (Structured Query Language) for database operations.

It is widely used in web and enterprise applications.



What is a Database?



A database is a collection of related data stored in an organized manner.

It helps in storing and managing information easily.

Databases support operations like insert, update, delete, and fetch.

Examples are MySQL, Oracle, and SQL Server.



What is SQL?



SQL stands for Structured Query Language.

It is used to communicate with databases.

SQL helps perform CRUD operations on data.

Commands include SELECT, INSERT, UPDATE, and DELETE.



What is the difference between DELETE, DROP, and TRUNCATE?



DELETE removes specific rows from a table using conditions.

TRUNCATE removes all rows but keeps the table structure.

DROP deletes the complete table including structure.

DELETE can be rolled back, while DROP and TRUNCATE usually cannot.



What is a Primary Key?



A Primary Key uniquely identifies each record in a table.

It does not allow duplicate or NULL values.

Each table can have only one primary key.

It helps maintain data uniqueness.



What is a Foreign Key?



A Foreign Key creates a relationship between two tables.

It refers to the Primary Key of another table.

It helps maintain referential integrity.

Foreign keys avoid invalid data entries.



What is the difference between WHERE and HAVING?



WHERE filters rows before grouping data.

HAVING filters data after GROUP BY operation.

WHERE cannot use aggregate functions directly.

HAVING is mainly used with aggregate functions.



What is a Join in MySQL?



Join is used to combine data from multiple tables.

Common joins are INNER JOIN, LEFT JOIN, RIGHT JOIN, and FULL JOIN.

Joins are based on related columns between tables.

They help retrieve meaningful combined data.



What is Normalization?



Normalization is the process of organizing data to reduce redundancy.

It improves database efficiency and consistency.

It divides large tables into smaller related tables.

Common forms are 1NF, 2NF, and 3NF.



What is Indexing in MySQL?



Indexing improves the speed of data retrieval operations.

It works similar to an index in a book.

Indexes reduce the time required to search records.

Too many indexes may affect insert and update performance.



Q) What is a transaction in SQL?



A transaction is a group of SQL operations executed as a single unit.

It follows ACID properties and ensures data integrity. If any step fails, the whole transaction is rolled back.



Q) What is a view in MySQL?



A view is a virtual table created from a SQL query.

It does not store data physically but shows data from one or more tables.

It helps simplify complex queries and improves security.



Q) What is a schema in database?



A schema is the structure or blueprint of a database.

It defines tables, columns, relationships, and constraints.

It helps organize database objects logically.



Q) What is a stored procedure?



A stored procedure is a set of SQL statements stored in the database.

It can be executed multiple times with different parameters.

It improves performance and reduces code repetition.



Q) What is a trigger in MySQL?



A trigger is a SQL block that automatically executes when an event occurs.

Events can be INSERT, UPDATE, or DELETE.

It is used to enforce rules and maintain data integrity.



Q) What is a constraint in SQL?



Constraints are rules applied to table columns to maintain data accuracy.

Examples include NOT NULL, UNIQUE, CHECK, PRIMARY KEY, and FOREIGN KEY.

They ensure valid data is stored in the database.



Q) What is normalization vs denormalization?



Normalization reduces data redundancy by splitting tables.

Denormalization combines tables to improve read performance.

Normalization is used for consistency, while denormalization is used for speed.



Q) What is a cursor in SQL?



A cursor is used to retrieve and process rows one by one from a result set.

It is mainly used in stored procedures and complex row-by-row processing.



Q) What is a candidate key?



A candidate key is a column (or set of columns) that can uniquely identify a row in a table.

From candidate keys, one is chosen as the primary key.



Q) What is data redundancy?



Data redundancy means storing the same data multiple times in a database.

It leads to inconsistency and wasted storage space.

Normalization helps reduce redundancy.

