testing 



**introduction**

**Hello Sir/Madam, my name is Hemant Chaudhari. I have completed my BE in Computer Engineering from MET Bhujbal Knowledge City, Nashik.**

**I worked as a Trainee Engineer and later as a Full Stack Engineer at Growingflowers Software Solutions. During this time, I worked on a hotel management system called SewaStay, where I was involved in backend development as well as manual testing.**

**My primary focus was on backend development, where I designed and developed REST APIs using Java and Spring Boot, and handled database operations using MySQL. Along with development, I also tested APIs using Postman and performed basic manual testing of my modules, as there was no dedicated QA team in the company.**

**Through this experience, I gained knowledge in both development and software testing.**

**Now, I am looking for an opportunity as a QA Engineer where I can apply my skills, improve my testing knowledge, and grow in a stable organization.”**





**why not tell me**

**“During that time, I had just started working again with my previous company, and my role was still evolving. Since my experience was not very stable or formally structured in QA, I presented myself as a fresher to keep things clear and accurate.**



**Now I have gained more clarity and confidence about my experience in API testing and manual testing, so I am explaining it properly.”**





**========================================================================================================================================================================**



**Q) how you use testing  in project   (“I used a demo e-commerce website for testing practice, such as**

**Demo Web Shop, which is commonly used for learning and testing purposes.”)**

**“I have mainly worked on backend using Java and Spring Boot.**

**While testing APIs using Postman, I performed black box testing by validating responses.**

**Since I understand the backend logic, I also applied grey box testing in some cases.**

**I have basic knowledge of white box testing concepts, but my main experience is in black box and API testing.”**





**========================================================================================================================================================================**



What is Agile Methodology?



Agile is a flexible and iterative development approach where work is done in small parts called sprints.

Each sprint delivers a working feature of the product.

It allows continuous feedback and quick changes.

Testing and development happen together.

👉 Used in most modern companies.





“I have worked in an Agile-like environment where development and testing were done in parallel, and we tested features continuously.”



**========================================================================================================================================================================**

What is Waterfall Model?



Waterfall is a sequential model where each phase is completed one after another.

Phases: Requirement → Design → Development → Testing → Deployment.

Once a phase is done, it is difficult to go back.

Testing is done only after development is complete.

👉 Used in old or fixed-requirement projects.



**========================================================================================================================================================================**





**Difference (Agile vs Waterfall)**

**Agile → Flexible, iterative**

**Waterfall → Fixed, sequential**

**Agile → Continuous testing**

**Waterfall → Testing at end**

**Agile → Customer feedback frequently**

**Waterfall → Feedback at final stage**



**========================================================================================================================================================================**







Q)I joined Growing Flower Software Solutions LLP in March 2025 as a remote full stack engineer intern. Initially, I received training in Spring Boot, and later I worked on API development and testing using Postman.

Around August, the company didn’t have enough projects, and operations slowed down, so it felt like things might shut down. During that time, I received an offer from Shakham.

But in November, my previous company reached out again and offered me a full-time role with a salary. Since I had already worked there and understood the system well, I felt it was better to continue with them.

However, due to financial losses, the company became unstable again and eventually shut down by March without being able to provide salaries. Because of that, I am now looking for a more stable opportunity.”



**========================================================================================================================================================================**







Q\_E-commerce Website Testing (Manual Testing)

“I worked on an e-commerce website testing project as a self-learning project to gain practical experience in manual testing.

I used an available e-commerce application and practiced testing real-time scenarios. I focused on key modules like Login, Search, Cart, and Checkout.

I designed and executed more than 20 test cases to validate different scenarios such as valid and invalid login, product search, adding items to the cart, and completing the checkout process.

I performed functional testing to verify that all features were working as per requirements, and regression testing to ensure that new changes did not affect existing functionality.

I also reported bugs with proper details like severity, priority, and steps to reproduce, and performed retesting after fixes to ensure system stability.”



**========================================================================================================================================================================**



q)What is Unit Testing?

Unit testing is a type of testing where individual parts of code (like a method or function) are tested separately.

It is mainly done by developers to check if each unit works correctly.

It helps in finding bugs early before integration.



**========================================================================================================================================================================**



Q)What is JUnit?

JUnit is a testing framework for Java used to perform unit testing.

It helps developers write and run test cases for individual methods or classes.

It is mainly used to check whether code is working correctly.

Key Features of JUnit

Uses annotations like @Test, @Before, @After

Provides assert methods to validate output

Helps in automating test execution

Easy integration with tools like Maven and Spring Boot



**========================================================================================================================================================================**





Q)What is Manual Testing?

Manual testing is the process of testing software without using automation tools.

Testers execute test cases manually to find defects.

It focuses on user experience and application behavior.



**========================================================================================================================================================================**



Q)What is Jira?

Jira is a tool used for bug tracking and project management.

It helps teams to create, track, and manage defects/issues.

Testers use Jira to report bugs with details like severity and priority.

It supports workflows like To Do, In Progress, and Done.

It is widely used in Agile and Scrum environments.



**========================================================================================================================================================================**





Q)What is Selenium?

Selenium is an automation testing tool used for web applications.

It helps testers write scripts to automate test cases.

It supports multiple languages like Java, Python, and C#.

It works on different browsers like Chrome, Firefox, and Edge.

It is mainly used for regression and repetitive testing.



**========================================================================================================================================================================**



Q)QA vs Manual Testing (Final Answer)

“QA focuses on improving the process to prevent defects and covers the entire development lifecycle.

It is proactive in nature and involves activities like process definition and quality standards.

QA ensures overall product quality, not just testing.



Manual testing is part of QA, where we execute test cases manually to find bugs in the application.

It is reactive in nature and focuses on identifying defects after development.

Manual testing checks functionality, usability, and user experience.



**========================================================================================================================================================================**





Q)Functional vs Non-Functional Testing

Functional testing checks whether features are working as per requirements.

It focuses on business logic like login, search, and checkout.

It answers ‘what the system does’.



Non-functional testing checks performance, usability, and security.

It focuses on how the system behaves.

It answers ‘how the system works’.”



**========================================================================================================================================================================**





Q)What is Black Box Testing?

Black box testing is testing where we do not know the internal code of the application.

We test based on requirements and functionality.

Focus is on input and output.

Example: Testing login page without knowing code.



**========================================================================================================================================================================**





Q)Which testing do you use?

“I mainly use black box testing because I test application functionality based on requirements.

But I have some understanding of backend logic, so I can also apply grey box testing.”



**========================================================================================================================================================================**





Q)What is Grey Box Testing?

Grey box testing is a combination of black box and white box testing.

Tester has partial knowledge of the system.

Used to test both functionality and internal structure.



**========================================================================================================================================================================**





Q)What is White Box Testing?

White box testing is testing where we have knowledge of internal code.

It focuses on logic, conditions, and code structure.

Usually done by developers.

Example: Checking loops, conditions, and code paths.



**========================================================================================================================================================================**



Q)Verification vs Validation

Verification checks whether we are building the product correctly as per requirements.

It involves activities like reviews, walkthroughs, and inspections.

It is done without executing the code.



Validation checks whether we are building the right product for the user.

It involves actual testing by executing the application.

It ensures the product meets user needs.”



**========================================================================================================================================================================**



Q)What is Software Testing?

Software testing is the process of verifying and validating an application.

It ensures the product works as expected and is bug-free.

It improves software quality and reliability.



**========================================================================================================================================================================**



Q)Smoke Testing

Smoke testing is basic testing to check whether the application build is stable or not.

It verifies core functionalities like login or app launch.

It is done before detailed testing to ensure the build is testable.



**========================================================================================================================================================================**



Q)Sanity Testing

Sanity testing checks specific functionality after small changes or bug fixes.

It ensures the issue is fixed and related features are working.

It is focused and narrow testing.



**========================================================================================================================================================================**



Q2) You have experience, so why are you applying as a fresher in QA?

Although I started as a backend developer intern, I was also responsible for testing my own APIs using tools like Postman because there was no dedicated QA team. This gave me hands-on experience in manual testing and understanding real-time scenarios. Since my QA experience is not in a formal role, I am applying at an entry level to build a strong foundation and grow professionally in testing.”



Q)“Although I started as a backend developer intern, I was also involved in testing our APIs using Postman, as we didn’t have a dedicated QA team. It was a group project, and our manager encouraged us to test our own modules, which led me to learn manual testing and understand how the application works from a user perspective.

This gave me hands-on experience with real-time scenarios and improved my overall understanding of quality assurance. Since my QA experience is not from a formal QA role, I’m applying at an entry level to build a strong foundation and grow further in testing.”

**========================================================================================================================================================================**



Q) Why are you looking for a job change?

“After working with Growingflowers Software Solutions, I gained good practical experience in both development and testing.

However, due to financial instability, the company operations slowed down and eventually shut down without salary continuity.

So now, I am looking for a stable organization where I can continue learning and contribute effectively, especially in the QA domain.”



Q)Why are you applying as a fresher in QA?



“Although I started as a backend developer intern, I was also responsible for testing APIs using Postman because there was no dedicated QA team.

I performed manual testing, created test cases, and validated application functionality.

Since my QA experience is not in a formal QA role, I am applying at an entry-level position to build a strong foundation and grow professionally in testing.”



**========================================================================================================================================================================**





Q)4. What is Software Testing?

“Software Testing is the process of verifying and validating an application to ensure it works as expected and is free from defects.



The main goal is to improve quality, find bugs, and ensure the product meets user requirements.”



**========================================================================================================================================================================**



Q)What is SDLC?

SDLC stands for Software Development Life Cycle. It defines the phases involved in developing software.

Phases include:

Requirement → Design → Development → Testing → Deployment → Maintenance.”

**========================================================================================================================================================================**



Q)What is STLC?

STLC stands for Software Testing Life Cycle. It includes all testing activities.

Phases:

Requirement Analysis → Test Planning → Test Case Design → Test Execution → Defect Reporting → Test Closure.”

**========================================================================================================================================================================**



Q)What is a Test Case?

“A test case is a set of steps, conditions, and expected results used to verify a particular functionality of an application.”

**========================================================================================================================================================================**



Q)Explain Severity vs Priority (VERY IMPORTANT 🔥)

Severity: How serious the bug is (impact on system)

Priority: How urgently it needs to be fixed

Example:

Login not working → High Severity, High Priority

UI misalignment → Low Severity, Low Priority



**========================================================================================================================================================================**



Q)What types of testing have you done?

“I have mainly worked on:

Functional Testing 

Regression Testing

API Testing using Postman

Manual Testing”

**========================================================================================================================================================================**



Q)How do you report a bug?



Answer:

“I report bugs with the following details:

Bug ID

Title

Description

Steps to reproduce

Expected result

Actual result

Severity

Priority

Screenshot (if needed)”

**========================================================================================================================================================================**



Q)Why should we hire you?

“I have practical experience in manual testing and API testing along with development knowledge.

I understand both developer and tester perspectives, which helps in finding bugs effectively.

I am quick to learn, dedicated, and ready to contribute to your QA team.”

**========================================================================================================================================================================**



Q)Bug / Defect

A bug or defect is an error in the software where the actual result does not match the expected result.

It occurs due to mistakes in coding, design, or requirements.

Bugs are identified during testing and reported for fixing.

**========================================================================================================================================================================**





Q)Functional Testing

Functional testing verifies that the application works according to the given requirements.

It checks features like login, form submission, and business logic.

Focus is on what the system does, not how it works internally.

**========================================================================================================================================================================**



Q)Regression Testing

Regression testing ensures that new changes or bug fixes do not break existing functionality.

It is performed after updates or enhancements in the application.

It helps maintain system stability over time.





**========================================================================================================================================================================**



What is Sprint?

A sprint is a fixed time period (usually 2–4 weeks) in Agile where a set of tasks or features are completed.

At the end of the sprint, a working product increment is delivered.

Testing and development both happen within the sprint.



👉 Example: Login feature completed in one sprint





**========================================================================================================================================================================**





What is Scrum Call (Daily Stand-up)?



Scrum call is a daily meeting (15 minutes) in Agile.

Team members discuss:



What they did yesterday

What they will do today

Any blockers



It helps track progress and resolve issues quickly.



**========================================================================================================================================================================**



What is Scrum Master?



Scrum Master is the person who manages the Agile process.

They ensure the team follows Scrum practices.

They remove blockers and help the team work smoothly.

They act as a bridge between team and management.





