###### Q)**tell me about your self**

“Hi, I’m Hemant Chaudhari. Thank you for giving me this opportunity to introduce myself.

I have completed my BE in Computer Engineering from MET Institute of Engineering, Nashik in 2024.

I have hands-on experience in full stack development using Java, Spring Boot, Angular, MySQL, along with Git and GitHub for version control.

I worked as a Full Stack Engineer at Growingflowers Software Solutions, where I developed a live hotel management system called SewaStay.

&#x20;My role involved both backend and frontend development,

&#x20;where I built REST APIs for booking, customer management, and room availability using Spring Boot, and also worked on Angular integration for the frontend.

I have also completed internships where I worked on employee management applications and developed scalable full stack applications using layered architecture.

&#x20;I am particularly interested in full stack development and I want to grow as a strong and efficient full stack developer working on scalable systems.”







**“In how many days are you available to join?”**

I am currently in Pune, and I am ready to relocate. I can join within 7–10 days depending on the joining formalities.

============================================================================================================================================================================================





\--------------- in my project, I did not store images directly in MySQL. Instead, I stored the image path (URL or file name) in the database, and the actual image was stored in the server file system. The database only keeps a reference to that image. This approach improves performance and avoids increasing database size.”---------------------------------------



============================================================================================================================================================================================





###### **explain your role in company**



“In my previous company, I worked as a Full Stack Engineer, with my primary focus on backend development. I was responsible for designing and developing REST APIs using Java and Spring Boot, and I handled database operations using MySQL. I followed a layered architecture like Controller, Service, DTO, and Repository to keep the code structured and maintainable. I also collaborated with frontend developers to integrate APIs and ensure smooth functionality. In one of my projects, Vadhu Var Suchika Matrimony, I initially worked on the frontend and later transitioned to backend development, where I contributed to API development and database integration. Additionally, I worked on debugging, API testing using Postman, and improving application performance.”



============================================================================================================================================================================================





###### **tell me your privous company**



I worked at Growingflowers Software Solutions as a Full Stack Engineer in a remote role. The company focuses on developing web-based applications and software solutions. During my time there, I worked on real-time projects like a hotel management system and a real estate application. My main focus was backend development using Java and Spring Boot. In one of my projects, Vadhu Var Suchika Matrimony, I initially worked on the frontend and later contributed to backend development, where I designed REST APIs and handled MySQL database operations. I also collaborated with the team to build scalable features and improve application performance. Overall, it gave me strong hands-on experience in real-world development.”

============================================================================================================================================================================================



###### 

###### **Why did you leave your previous company?**

My previous company had a one-year service agreement, during which I gained valuable hands-on experience in Java, Spring Boot, and real-time projects. I have completed my learning phase there, and now I’m looking for better growth opportunities, more challenging work, and a chance to further enhance my skills in a professional environment.”



Salary Expectation

As a fresher, my main focus is on learning and growth. I’m open to a salary in line with company standards and industry norms. However, based on my skills and experience, I would expect a fair and competitive package, ideally in the range of 2 to 3 LPA, but I’m flexible depending on the role and learning opportunities.”

============================================================================================================================================================================================







###### **What do you know about our company?**

Yes, SPEC INDIA is a software development company that focuses on building custom applications and digital transformation solutions. I saw that you work on technologies like AI, cloud, and enterprise systems, and you have delivered many global projects. I’m particularly interested because your work involves scalable backend systems, which matches my experience.



============================================================================================================================================================================================



###### paradise heven project



Paradise Haven is a real estate management system that I developed using Java, Spring Boot, Hibernate, and MySQL. The main purpose of the project is to allow users to register, log in, and manage property listings. I primary work on froend then go to the  worked on the backend where I designed REST APIs for handling user and property operations. I followed a layered architecture with Controller, Service, and DAO to keep the code structured and maintainable. I also integrated the database using Hibernate to perform CRUD operations efficiently. This project helped me understand how to build a scalable backend system and manage real-time data flow.



&#x20;  **chanlleges faced**

// Paradise Haven is a real estate management system I worked on using Java, Spring Boot, Hibernate, and MySQL, where users can easily register, log in, and manage property listings. We were a team of 2 people where we both work on fronted a well as backend I worked as a backend developer. I mainly handled the user and property modules by creating REST APIs and following a proper layered structure like Controller, Service, and DAO. I also tested the APIs using Postman to make sure everything was working smoothly. **One challenge I faced was managing** data flow and relationships in Hibernate, which caused some issues at first, but I fixed it by improving the entity design and debugging step by step. Overall, this project really helped me understand how real backend systems are built and how to handle data efficiently.   //



============================================================================================================================================================================================





###### **student managemtn system**

I implemented the Student Management System as my own full-stack project using Angular and Spring Boot. It allows users to add, update, and delete student records with a simple and user-friendly interface. I built the frontend using Angular with routing and form validation, and developed REST APIs on the backend using a layered architecture (Controller, Service, DAO) with MySQL. **One challenge I faced was** integrating the frontend with backend APIs and handling data flow properly. I solved it by testing APIs in Postman, fixing endpoints, and improving Angular service calls step by step.



============================================================================================================================================================================================





Q26: Multiple users booking same room (brief answer)

“Sir, to handle multiple users booking the same room at the same time, I use database-level control and validation.



First, I check room availability before booking. Then I use transactions to ensure only one booking is successful.



If two users try at the same time, the database ensures only one transaction is committed, and the other fails.



We can also use locking or status flags to avoid double booking.”

============================================================================================================================================================================================





###### **hotel managmeant system**



SewaStay is a live hotel management system I worked on in my company using Java, Spring Boot, and MySQL to manage room booking, customer details, and availability. Initially, I was working on the frontend module, but later I also took responsibility for backend development based on project needs. I designed REST APIs for booking, customer, and room management, and followed a layered architecture (Controller, Service, Repository) to keep the code structured. I also worked on database integration and API testing to ensure smooth data flow. This project gave me practical experience in working on real-time applications and understanding how frontend and backend integrate.***One challenge I faced was handling duplicate room booking. When multiple users tried to book the same room, it caused conflicts. I solved this by adding validation and checking room availability before confirming the booking***.”



// changlledeg faced

***In my project SewaStay, we developed a hotel management system to manage room booking, customer details, and availability.***

***We used a layered architecture with Controller, Service, and Repository layers. Controller handles requests, Service contains business logic, and Repository interacts with the MySQL database.***

***My role was mainly backend development. I created REST APIs for customer management, room booking, and availability, and integrated them with the database.***

***One challenge I faced was handling duplicate room booking. When multiple users tried to book the same room, it caused conflicts. I solved this by adding validation and checking room availability before confirming the booking***.”





============================================================================================================================================================================================





**what is the difference between Monolithic and Microservices architecture?**

**And which one did you use in your project?**

Monolithic architecture means the entire application is built and deployed as a single unit, where all modules like UI, business logic, and database are tightly coupled.

Microservices architecture means the application is divided into small independent services, where each service handles a specific functionality and can be developed and deployed separately.

In monolithic, scaling is difficult because we scale the whole application, while in microservices we can scale only required services.

In my project, I used monolithic architecture with layered design (Controller, Service, Repository).”



============================================================================================================================================================================================





###### **if your project is monolithic, then how will you convert it into microservices?**

###### &#x20;**Explain high-level approach.**



Sir, to convert a monolithic application into microservices, first I will identify different modules in the system, like booking, customer, and payment.

Then I will separate each module into independent services, where each service has its own logic and database.

After that, I will make them communicate using REST APIs.

Finally, I will deploy each service separately and use an API Gateway to manage requests.”



============================================================================================================================================================================================







**Are you comfortable shifting to Ahmedabad?**

Yes, I’m currently based in Pune, and I’m comfortable relocating to Ahmedabad for the right opportunity. I see it as a good step for my career growth.”



**Relocation**

I’ve thought about it, and I’m ready to manage the relocation. Initially, I can stay in a hotel or temporary accommodation, and meanwhile I’ll look for a permanent place. I’m flexible and can adapt quickly to a new city and work environment.”



============================================================================================================================================================================================





**9. What kind of SQL queries did you use?**



“I mostly used CRUD operations like INSERT, SELECT, UPDATE, and DELETE. Along with that, I used JOIN queries to fetch related data. I also used aggregate functions for reports. These queries handled most of the application logic.”



**10. Did you face SQL performance issues?**



“Yes, sometimes queries were slow with large data. I improved performance by optimizing queries and using indexing. I also reduced unnecessary data fetching. This helped improve response time.”



============================================================================================================================================================================================





@GetMapping is used to retrieve data from the server. It is mainly used for reading data from the database.



@PostMapping is used to send data to the server, usually to create a new record in the database.



@POST is used to create a new resource in the database. Every time we call POST, it creates a new entry.



@PUT is used to update an existing resource. If the resource exists, it updates it; if not, it can also create it depending on implementation.

